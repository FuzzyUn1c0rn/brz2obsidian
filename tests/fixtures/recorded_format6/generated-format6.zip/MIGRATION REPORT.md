# Migration report

Open the root Home note to begin. Safe original note bytes are retained under Attachments. Forgotten thoughts are excluded by default; unsafe originals and unscopable history are omitted. Counts describe included scope.

Created 1 thought notes; preserved 1 present payloads.

Unsupported feature classes are refused explicitly.

[[Vault guide.md|Vault guide]] explains manual full-template selection for new objects, direct membership edits on existing notes, canonical properties and future-category starters. Bundled Templates is configured for insertion-day ISO dates; update dates are maintained explicitly.

Open [[Categories.md|Categories]] from Home, then a category dashboard for its native Members table and Gallery after the title and any Parents/Children navigation, without a generated introductory category image. Retained source content and resources follow the Bases; category icon properties remain available for dashboard images. These contextual Bases use the embedding category and follow link-preserving category renames; a standalone member Base has no category context. Edit categories to change membership and appearance_category to choose a member's icon provider independently of membership order. A valid local icon override wins, an empty provider opts out, and an invalid provider is shown without selecting a substitute. Category icon edits update inherited dashboard images; ordinary/member note-body image references remain separately editable migration-time snapshots. Declared colours remain in migration-record.json only. Bundled Bases and link updates are configured.
