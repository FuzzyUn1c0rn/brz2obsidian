# Categories

![[Templates/Bases/Categories.base]]
